import os.path

import pygame as pg
import random


# define colors, colors work in a (RGB) format.
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255,255,0)
TEAL = (0,255,255)
PINK = (255,0,255)
ORANGE = (255,127,0)
DARK_GRAY = (64,64,64)
LIGHT_GRAY = (192,192,192)
GRAY_BLUE = (92,192,194)

colors = (WHITE,BLUE,BLACK,RED,GREEN,YELLOW,TEAL,PINK,ORANGE)



#Game Title
TITLE = "Galatic JoyRide"



# Window Settings
WIDTH = 750
HEIGHT = 1000
DEFAULT_COLOR = BLACK
TILE_SIZEX = WIDTH/15
TILE_SIZEY = HEIGHT/15
debugging = False


# camera settings
fps = 40




# file locations
#gets location of file on computer
game_folder = os.path.dirname(__file__)
game_folder = game_folder.replace("\scripts","")
sprites_folder = os.path.join(game_folder,"sprites")
player_folder = os.path.join(sprites_folder,"playerSprites")
enemy_folder = os.path.join(sprites_folder,"enemySprites")
background_folder = os.path.join(sprites_folder,"backgrounds")
explosions_folder = os.path.join(background_folder,"explosions")
ammo_folder = os.path.join(player_folder,"ammo")
powerups_folder = os.path.join(player_folder,"powerups")
sound_folder = os.path.join(game_folder,"snd")
fx_snd_folder = os.path.join(sound_folder, "effects")
ambience_snd_folder = os.path.join(sound_folder,"ambience")
music_snd_folder = os.path.join(sound_folder,"music")


#backgrounds

bg_images = ["Map_01_1080x3000.png","Map_02_1080x3000.png","Map_04_1080x3000.png","Space_BG_01.png","Space_BG_02.png","Space_BG_03.png","Space_BG_04.png"]

bg_img = os.path.join(background_folder,random.choice(bg_images))




# player Settings
solidbounds = True

player_fire_rate = 4
playerSpeed = 12
player_w = 65
player_h = 65
bullet_w = 12
bullet_h = 30
powerup_w = 40
powerup_h = 40



playerPersonalIMG = os.path.join(player_folder,"spaceship.png")
playership9 = os.path.join(player_folder,"Ship_LVL_4.png")



player_bullet = os.path.join(ammo_folder,"Missile_02.png")


 #name and odd of getting power
fast_Fire = "Enemy_Speed_Debuff.png"
double_Shot = "Rockets_Bonus.png"
extra_life = "HP_Bonus.png"
increase_shields = "Armor_Bonus.png"
w_shot = "Damage_Bonus.png"
increase_max_shields = "Barrier_Bonus.png"


pow_filename_list = ["Armor_Bonus.png","Enemy_Speed_Debuff.png","Damage_Bonus.png","HP_Bonus.png"]

powerup_list = [double_Shot,fast_Fire,extra_life,increase_shields,w_shot,increase_max_shields]




# Enemy Settings
meteors = []

for i in range(10):
    meteors.append(os.path.join(enemy_folder,"Meteor_"+str(i+1)+".png"))

print(meteors)







