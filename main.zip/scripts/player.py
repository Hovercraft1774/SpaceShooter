from scripts.settings import *


class Player(pg.sprite.Sprite):#must be a sprite inherited otherwise it won't fit in groups

    def __init__(self,game,x,y,color_key):
        super(Player,self).__init__()

        self.game = game #adds reference to the game
        # self.image = pg.image
        # self.image.load(self.image)
        self.frame = 0
        self.origional_y = y

        self.image = self.game.player_imgs[self.frame]
        self.image.set_colorkey(color_key)#gets rid of black color and makes it transparent
        self.color_key = color_key
        self.rect = self.image.get_rect()
        self.radius = player_w*0.85//2

        # self.image = pg.Surface((50,50)) #creates and makes this thing a rectangle
        # self.image.fill(color)
        # self.rect = self.image.get_rect()
        self.speed = playerSpeed
        self.shields = 100
        self.lives = 3
        self.hidden = False #off screen
        self.invincible = False
        self.hideTimer = 10

        if debugging:
            pg.draw.circle(self.image,WHITE,self.rect.center,self.radius,2)

        self.rect.center = (x,y)
        self.last_update = pg.time.get_ticks()
        self.frame_rate = fps


        self.xMove = 0
        self.solidbounds = solidbounds
        self.addToGroups()
        self.canShoot = True
        self.fire_rate = 5
        self.bulletAmount = 1
        self.currentPowers = []
        self.powerTimer = 0
        self.shootCooldown = fps/2
        self.maxShields = 100

    def animate(self):
        now = pg.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == len(self.game.player_imgs):
                self.frame = 0
            else:
                old_center = self.rect.center
                self.image = self.game.player_imgs[self.frame]
                self.image.set_colorkey(BLACK)
                self.rect = self.image.get_rect()
                self.rect.center = old_center


    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.player_group.add(self)

    def get_image(self,img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (player_w, player_h))
        return self.img


    def setMoveX(self,speed):
        if self.solidbounds:
            if self.rect.right >= WIDTH:
                self.rect.right = WIDTH
            if self.rect.bottom >= HEIGHT:
                self.rect.bottom = HEIGHT

            if self.rect.left <= 0:
                self.rect.left = 0

            if self.rect.top <= 0:
                self.rect.top = 0
        else:
            if self.rect.left > WIDTH:
                self.rect.right = 0
            if self.rect.top > HEIGHT:
                self.rect.bottom = 0

            if self.rect.right < 0:
                self.rect.left = WIDTH

            if self.rect.bottom < 0:
                self.rect.top = HEIGHT

        self.rect.x += speed

    def collect(self,powertype):
        if powertype == w_shot:
            self.currentPowers.append("W_Shot")
            self.game.powerupList.remove(powertype)
            print("Obtained W_Shot")
        if powertype == fast_Fire:
            if "FastFire" not in self.currentPowers:
                self.currentPowers.append("FastFire")
                self.game.powerupList.remove(powertype)
                print("Obtained FastFire")
        elif powertype == double_Shot:
            if "DoubleShot" not in self.currentPowers:
                self.currentPowers.append("DoubleShot")
                self.game.powerupList.remove(powertype)
                print("Obtained DoubleShot")
        elif powertype == extra_life and self.lives <= 5:
            self.gain_life()
            print("Gained a Life")
        elif powertype == increase_shields:
            self.gainShields(random.randint(20, 40))
            print("Increased Shields")
        elif powertype == increase_max_shields:
            self.maxShields += 20
            self.gainShields(random.randint(20, 40))
            print("Increased Max Shields")

    def shoot(self):

        Bullet(self.game, self.rect.centerx, self.rect.top-10,0,-10,player_bullet,self.color_key)
        if "DoubleShot" in self.currentPowers: #adds 2 bullets to the sides
            self.lf_bullet =Bullet(self.game, self.rect.centerx-22.5, self.rect.top - 2,0,-10, player_bullet, self.color_key)
            self.rf_bullet = Bullet(self.game, self.rect.centerx+22.5, self.rect.top - 2,0,-10, player_bullet, self.color_key)
        if "W_Shot" in self.currentPowers: #makes the w with shots
            self.left_bullet = Bullet(self.game, self.rect.centerx - 30, self.rect.top - 2, -5, -7, player_bullet, self.color_key)
            self.left_bullet.rotate(25)#bullet flying to the left
            self.right_bullet = Bullet(self.game, self.rect.centerx + 30, self.rect.top - 2, 5, -7, player_bullet, self.color_key)
            self.right_bullet.rotate(-25)#bullet flying to the right
            if "DoubleShot" in self.currentPowers:
                self.lf_bullet.move_x = -1.5
                self.lf_bullet.rotate(12)#left front rotate
                self.rf_bullet.move_x = 2.5
                self.rf_bullet.rotate(-12) #right front rotate
        self.game.laser_snd.play()

    def takeShields(self,amount):
        self.shields -= amount
    def gainShields(self,amount):
        if self.shields < self.maxShields:
            self.shields += amount
        if self.shields >self.maxShields:
            self.shields = self.maxShields+25


    def take_life(self):
        self.hidden = True
        self.rect.y = HEIGHT+500
        self.lives -= 1
        if int(len(self.currentPowers)) > 0:
            self.currentPowers.remove(random.choice(self.currentPowers))
    def gain_life(self):
        self.lives += 1


    def update(self):
        self.animate()

        self.xMove = 0

        keys = pg.key.get_pressed()
        if keys[pg.K_a or pg.K_LEFT]:  # if key is being pressed, move left
            self.setMoveX(-self.speed)
        if keys[pg.K_d or pg.K_RIGHT]:  # if key is being pressed, move right
            self.setMoveX(self.speed)
        if keys[pg.K_SPACE]:
            if self.canShoot:
                self.canShoot = False
                self.shoot()

        if self.hidden:
            self.rect.y -= 1000
            self.hideTimer -= .1

        if self.hideTimer <= 0: #death
            self.hideTimer = 10
            self.hidden = False
            self.shields = 100
            self.maxShields = 100
            self.invincible = False
            self.rect.centery = self.origional_y

        if self.shields > self.maxShields:
            self.shield_color = ORANGE
        elif self.shields > self.maxShields/2:
            self.shield_color = BLUE
        elif self.shields > self.maxShields/5:
            self.shield_color = YELLOW
        else:
            self.shield_color = RED





        if self.game.getSecond(self.fire_rate,self.shootCooldown):
            self.canShoot = True
        else:
            self.canShoot = False


        if "FastFire" in self.currentPowers:
            self.fire_rate = 10
            self.shootCooldown = 5
        elif "FastFire" not in self.currentPowers:
            self.fire_rate = 5
            self.shootCooldown = fps/2



        self.game.check_Events()
        #temporary auto move


class Bullet(pg.sprite.Sprite):
    def __init__(self,game,x,y,x_move,y_move,img,color_key):
        super(Bullet, self).__init__()

        # self.image = self.get_image(img_dir)
        # self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        # self.rect = self.image.get_rect()
        self.game = game  # adds reference to the game
        # self.image = pg.Surface((5,25)) #creates and makes this thing a rectangle
        # self.image.fill(BLUE)
        self.image_origional = img
        self.color_key = color_key
        self.image = self.get_image(self.image_origional)
        self.image.set_colorkey(self.color_key)#gets rid of black color and makes it transparent
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.move_y = y_move
        self.move_x = x_move
        self.addToGroups()

    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.bullet_group.add(self)

    def update(self):
        self.rect.centery += self.move_y
        self.rect.centerx += self.move_x
        if self.rect.bottom < 0:
            self.kill()

    def rotate(self,rot):
        self.rot = (rot)%360
        new_image = pg.transform.rotate(self.get_image(self.image_origional).copy(),self.rot)
        old_center = self.rect.center
        self.image = new_image
        self.rect = self.image.get_rect()
        self.rect.center = old_center
        self.image.set_colorkey(self.color_key)

    def get_image(self,img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (bullet_w, bullet_h))
        return self.img


class Powerup(pg.sprite.Sprite):
    def __init__(self,game,x,y,type,color_key):
        super(Powerup, self).__init__()

        # self.image = self.get_image(img_dir)
        # self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        # self.rect = self.image.get_rect()
        self.game = game  # adds reference to the game
        # self.image = pg.Surface((5,25)) #creates and makes this thing a rectangle
        # self.image.fill(BLUE)
        self.image = self.get_image(os.path.join(powerups_folder,type))
        self.image.set_colorkey(color_key)  # gets rid of black color and makes it transparent
        self.powertype = type
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.radius = powerup_w * 0.85 // 2
        self.move_y = 7
        self.addToGroups()


    def addToGroups(self):
        self.game.all_sprites.add(self)
        self.game.powerup_group.add(self)

    def update(self):
        self.rect.centery += self.move_y
        if self.rect.top < 0:
            self.kill()

    def get_image(self, img_dir):
        self.img = pg.image.load(img_dir).convert()
        self.img = pg.transform.scale(self.img, (powerup_w, powerup_h))
        return self.img



class BROADBENT_Power_ups(pg.sprite.Sprite):
    def __init__(self,game,pos,type):
        super(BROADBENT_Power_ups,self).__init__()
        self.type = type
        self.game = game
        self.image = self.game.pow_imgs[self.type]
        self.image.set_colorkey()
        self.rect = self.image.get_rect()
        self.rect.center = pos
        self.speed = 4
