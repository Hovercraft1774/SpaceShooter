from scripts.settings import *
from scripts.player import *
from scripts.enemy import *
from scripts.explosions import *



class Game(object):

    def __init__(self):
        self.playing = True
        pg.init()
        pg.mixer.init() #if using online editor, take this out
        # creates a screen for the game
        self.screen = pg.display.set_mode((WIDTH,HEIGHT))
        pg.display.set_caption(TITLE) #Title of the screen window
        # creates time
        self.clock = pg.time.Clock()
        self.player_imgs = []
        self.mod_img = []

        self.font_name = pg.font.match_font("comic_sans")


        self.explosion_animation = {}
        self.explosion_animation["L"] = []
        self.explosion_animation["S"] = []

        # create Sprite Groups
        self.all_sprites = pg.sprite.Group()
        self.enemy_group = pg.sprite.Group()
        self.player_group = pg.sprite.Group()
        self.bullet_group = pg.sprite.Group()
        self.powerup_group = pg.sprite.Group()
        self.defaultColor = DEFAULT_COLOR

        self.debugging = debugging
        self.totalScore = 0
        self.maxAsteroids = 25
        self.powerupList = powerup_list #list of possible player powerups
        self.next_group_score = 5000 #how much score till added meteors

        self.cur_power = None


        self.frame_rate = fps
        self.last_update = pg.time.get_ticks()


        #create player player objects
        self.load_imgs()
        self.load_snd()
        self.player = Player(self,WIDTH/4,HEIGHT-50,self.defaultColor)

    def load_snd(self):
        self.explotion_snd = pg.mixer.Sound(os.path.join(fx_snd_folder,"explosion_x.wav"))
        self.laser_snd = pg.mixer.Sound(os.path.join(fx_snd_folder,"pew.wav"))
        self.laser_snd.set_volume(.1)
        self.explotion_snd.set_volume(.4)
        self.track1 = pg.mixer.music.load(os.path.join(music_snd_folder,"vengeanceElectro.wav"))
        self.track2 = pg.mixer.music.load(os.path.join(music_snd_folder,"brokenLife.wav"))

        pg.mixer.music.set_volume(0.7)


    def load_imgs(self):
    #background
        self.bg_img = pg.image.load(os.path.join(background_folder,bg_img)).convert()
        self.bg_img = pg.transform.scale(self.bg_img,(WIDTH,HEIGHT))


    #player
        for i in range(10):
            filename = str.format("Exhaust_4_1_00{}.png",i)
            player_img = pg.image.load(os.path.join(player_folder,filename)).convert()
            player_img = pg.transform.scale(player_img,(player_w,player_h))
            self.player_imgs.append(player_img)
        self.player_Life = pg.image.load(os.path.join(player_folder,"Ship_LVL_4.png"))
        self.player_Life = pg.transform.scale(self.player_Life,[35,35])


    #explosions
        for i in range(9):
            filename = str.format("Missile_2_Explosion_00{}.png", i)
            img = pg.image.load(os.path.join(explosions_folder,filename)).convert()
            img.set_colorkey(self.defaultColor)
            img_l = pg.transform.scale(img,(75,75))
            img_s = pg.transform.scale(img,(25,25))
            self.explosion_animation["L"].append(img_l)
            self.explosion_animation["S"].append(img_s)

    #powerups
        # self.pow_imgs = {}
        # for i in range(len(powerup_list)):
        #     self.pow_imgs[powerup_list[i]] = pg.image.load(os.path.join(powerups_folder,filename)).convert()
        #     self.pow_imgs[powerup_list[i]]] = pg.transform.scale(self.pow_imgs[powerup_list[i]],(powerup_w,powerup_h)


        #create enemy objects

    def spawnEnemies(self):
        for i in range(self.maxAsteroids - len(self.enemy_group)):
            self.mob = Mob(self, random.choice(meteors), self.defaultColor)




    def getSecond(self,time_speed_mod=1,time_slow_mod=1):
        now = pg.time.get_ticks()
        if (now - self.last_update)+time_speed_mod > self.frame_rate*time_slow_mod:
            self.last_update = now
            return True
        else:
            return False

    def gameLoop(self):
        pg.mixer.music.play(loops=-1)
        while self.playing:
            #tick clock
            self.clock.tick(self.frame_rate)

            #check events
            self.check_Events()

            #update all
            self.update()

            #draw
            self.draw()



    def check_Events(self):
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()


            if event.type == pg.KEYDOWN:
                if event.key == pg.K_m: #initiate mouse movement/cancel it
                    self.player.mouseMovement = not self.player.mouseMovement


        if self.totalScore>self.next_group_score:
            self.maxAsteroids += 5
            self.next_group_score *= 1.5
            print("added to max")

        if self.maxAsteroids > len(self.enemy_group):
            self.spawnEnemies()



        #if single sprite hit anything in blank group, kill group object?
        # hits = pg.sprite.spritecollide(self.player,self.enemy_group,False)
        #if group hit group, kill group1 or 2
        hits = pg.sprite.spritecollide(self.player, self.enemy_group, True,pg.sprite.collide_circle)  # checks for player sprite collision
        if hits and not self.player.invincible:
            if self.player.shields <= 0:
                self.player.take_life()
                self.player.invincible = True
                if self.player.lives <= 0:
                    self.playing = False  # ends game if hit
            else:
                amount = random.randint(5,35)
                self.player.takeShields(amount)



        hits = pg.sprite.groupcollide(self.enemy_group, self.bullet_group, True,True)  # check for collision between bullets and mobs

        if hits:
            for hit in hits:
                #explosion for asteroids
                exp = Explosion(self, hit.rect.center, "L")
                self.totalScore += 100
                self.explotion_snd.play()

            # check/spawn powerup
                z = random.randint(0,30)
                # z = 0
                if z == 0:
                    if int(len(self.powerupList)) >0:
                        self.cur_power = random.choice(self.powerupList)
                        self.powerup = Powerup(self,hit.rect.centerx,hit.rect.centery,self.cur_power,self.defaultColor)
                        self.totalScore += 1000






        hits = pg.sprite.groupcollide(self.powerup_group, self.player_group, True, False) #checks if hit powerup

        for hit in hits:
            self.player.collect(hit.powertype)





    def update(self):
        self.all_sprites.update()

    def draw(self):
        self.screen.fill(BLACK)
        self.screen.blit(self.bg_img,self.bg_img.get_rect())
        self.all_sprites.draw(self.screen)

        self.life_counter(5,30,self.player.lives,self.player_Life)


        # self.background.blit(self.screen)
        self.draw_Text(str(self.totalScore),30,WIDTH/2,30,WHITE)
        self.draw_Bar(5,5,300,25,self.player.shields,self.player.shield_color,RED)




        # think whiteboard, must be last line
        pg.display.flip()

    def draw_Bar(self,x,y,w,h,pct,fillColor,outlineColor):
        if pct < 0:
            pct = 0

        BAR_LEN = w
        BAR_HEIGHT = h
        fill_ammount = (pct/100)*BAR_LEN
        outline = pg.Rect(x,y,BAR_LEN,BAR_HEIGHT)
        fill_rect = pg.Rect(x,y,fill_ammount,BAR_HEIGHT)
        pg.draw.rect(self.screen,outlineColor,outline,2)
        pg.draw.rect(self.screen,fillColor,fill_rect)


    def draw_Text(self, text, size, x, y, color):
        font = pg.font.Font(self.font_name, size)
        text_sprite = font.render(text, True, color)
        text_rect = text_sprite.get_rect()
        text_rect.midtop = (x, y)
        self.screen.blit(text_sprite, text_rect)

    def life_counter(self,x,y,lives,img):
        for i in range(lives):
            img_rect = img.get_rect()
            img_rect.x += x+40*i
            img_rect.y = y
            self.screen.blit(img,img_rect)

    def start_Screen(self):
        pass
    def end_Screen(self):
        self.draw_Text("You lose!",50,WIDTH/2,HEIGHT/2,WHITE)
        print("You lost")